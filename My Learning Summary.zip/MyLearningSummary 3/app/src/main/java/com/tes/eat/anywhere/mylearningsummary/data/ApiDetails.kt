package com.tes.eat.anywhere.mylearningsummary.data

object ApiDetails {
    const val BASE_URL="https://61e947967bc0550017bc61bf.mockapi.io/"
    const val PEOPLE="api/v1/people"
    const val ROOM="api/v1/room"
}