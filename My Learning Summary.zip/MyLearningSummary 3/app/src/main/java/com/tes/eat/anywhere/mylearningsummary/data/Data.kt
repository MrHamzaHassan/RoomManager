package com.tes.eat.anywhere.mylearningsummary.data

data class Data(
    val body: String = "",
    val fromId: String = "",
    val id: String = "",
    val meetingid: String = "",
    val title: String = "",
    val toId: String = ""
)