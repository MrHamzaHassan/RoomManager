package com.tes.eat.anywhere.mylearningsummary.data

class People : ArrayList<PeopleItem>()