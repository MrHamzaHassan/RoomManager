package com.tes.eat.anywhere.mylearningsummary.ui.people


import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.tes.eat.anywhere.mylearningsummary.R
import com.tes.eat.anywhere.mylearningsummary.data.People
import com.tes.eat.anywhere.mylearningsummary.data.PeopleItem

import com.tes.eat.anywhere.mylearningsummary.databinding.ItemPersonFirstLastNameBinding

class PeopleAdapter(
    private val persons: People

) : RecyclerView.Adapter<PeopleAdapter.PeopleViewHolder>(), Parcelable {

    class PeopleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        //private val binding = ItemPersonBinding.bind(itemView)
        private val bindingFirstLastName = ItemPersonFirstLastNameBinding.bind(itemView)

        fun setupUI(fact: PeopleItem){
                //binding.tvPersonFact.text = fact?.get(position)?.firstNameModel
            bindingFirstLastName.tvName.text = "${fact.firstNameModel} ${fact.lastNameModel}"
            bindingFirstLastName.tvJob.text = "{fact.jobtitleModel}"
            // GLIDE for image  loading
            Glide.with(itemView.context)
                .load(fact.avatar)
                .placeholder(R.drawable.ic_launcher_background)
                .into(bindingFirstLastName.ivUserImage)
        }

    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeopleAdapter.PeopleViewHolder {
        return PeopleViewHolder(
            //LayoutInflater.from(parent.context).inflate(R.layout.item_person, parent, false)
            LayoutInflater.from(parent.context).inflate(R.layout.item_person_first_last_name, parent, false)

        )
    }
    override fun onBindViewHolder(holder: PeopleViewHolder, position: Int) {
        holder.setupUI(persons[position])
    }
    override fun getItemCount() = persons.size
    override fun writeToParcel(parcel: Parcel, flags: Int) {

    }

    override fun describeContents(): Int {
        return 0
    }



        override fun newArray(size: Int): Array<PeopleAdapter?> {
            return arrayOfNulls(size)
        }
    }

}